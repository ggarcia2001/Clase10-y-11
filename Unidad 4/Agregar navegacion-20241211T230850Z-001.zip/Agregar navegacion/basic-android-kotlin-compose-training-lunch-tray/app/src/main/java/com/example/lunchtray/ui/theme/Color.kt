/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.lunchtray.ui.theme

import androidx.compose.ui.graphics.Color

// Tema Claro
val md_theme_light_primary = Color(0xFF008577) // Verde azulado vibrante
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFB2DFDB)
val md_theme_light_onPrimaryContainer = Color(0xFF00332F)
val md_theme_light_secondary = Color(0xFFFD8700) // Naranja cálido
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFFFE4C2)
val md_theme_light_onSecondaryContainer = Color(0xFF4D2900)
val md_theme_light_tertiary = Color(0xFF005F73) // Azul océano
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFCBE3E7)
val md_theme_light_onTertiaryContainer = Color(0xFF00252A)
val md_theme_light_error = Color(0xFFB00020)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_errorContainer = Color(0xFFF9D6D6)
val md_theme_light_onErrorContainer = Color(0xFF410002)
val md_theme_light_outline = Color(0xFF8E8E8E)
val md_theme_light_background = Color(0xFFFFFBF2)
val md_theme_light_onBackground = Color(0xFF1C1C1C)
val md_theme_light_surface = Color(0xFFFFFBF2)
val md_theme_light_onSurface = Color(0xFF1C1C1C)
val md_theme_light_surfaceVariant = Color(0xFFE0E0E0)
val md_theme_light_onSurfaceVariant = Color(0xFF484848)
val md_theme_light_inverseSurface = Color(0xFF313131)
val md_theme_light_inverseOnSurface = Color(0xFFF4F4F4)
val md_theme_light_inversePrimary = Color(0xFF00796B)
val md_theme_light_surfaceTint = Color(0xFF008577)
val md_theme_light_outlineVariant = Color(0xFFCACACA)
val md_theme_light_scrim = Color(0xFF000000)

// Tema Oscuro
val md_theme_dark_primary = Color(0xFF00BFA5)
val md_theme_dark_onPrimary = Color(0xFF003731)
val md_theme_dark_primaryContainer = Color(0xFF00574B)
val md_theme_dark_onPrimaryContainer = Color(0xFFB2DFDB)
val md_theme_dark_secondary = Color(0xFFFFAB40)
val md_theme_dark_onSecondary = Color(0xFF4A2A00)
val md_theme_dark_secondaryContainer = Color(0xFF775000)
val md_theme_dark_onSecondaryContainer = Color(0xFFFFE4C2)
val md_theme_dark_tertiary = Color(0xFF73D8E3)
val md_theme_dark_onTertiary = Color(0xFF00363B)
val md_theme_dark_tertiaryContainer = Color(0xFF00515A)
val md_theme_dark_onTertiaryContainer = Color(0xFFCBE3E7)
val md_theme_dark_error = Color(0xFFF28B82)
val md_theme_dark_onError = Color(0xFF7A1C1C)
val md_theme_dark_errorContainer = Color(0xFF93000A)
val md_theme_dark_onErrorContainer = Color(0xFFF9D6D6)
val md_theme_dark_outline = Color(0xFF9E9E9E)
val md_theme_dark_background = Color(0xFF1C1C1C)
val md_theme_dark_onBackground = Color(0xFFE1E1E1)
val md_theme_dark_surface = Color(0xFF1C1C1C)
val md_theme_dark_onSurface = Color(0xFFE1E1E1)
val md_theme_dark_surfaceVariant = Color(0xFF484848)
val md_theme_dark_onSurfaceVariant = Color(0xFFC7C7C7)
val md_theme_dark_inverseSurface = Color(0xFFE1E1E1)
val md_theme_dark_inverseOnSurface = Color(0xFF313131)
val md_theme_dark_inversePrimary = Color(0xFF00BFA5)
val md_theme_dark_surfaceTint = Color(0xFF00BFA5)
val md_theme_dark_outlineVariant = Color(0xFF484848)
val md_theme_dark_scrim = Color(0xFF000000)