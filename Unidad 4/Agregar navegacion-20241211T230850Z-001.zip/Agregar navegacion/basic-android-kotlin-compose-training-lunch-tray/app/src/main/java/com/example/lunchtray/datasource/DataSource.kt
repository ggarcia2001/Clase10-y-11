/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.lunchtray.datasource

import com.example.lunchtray.model.MenuItem.AccompanimentItem
import com.example.lunchtray.model.MenuItem.EntreeItem
import com.example.lunchtray.model.MenuItem.SideDishItem

/**
 * Map of available menu items to be displayed in the menu fragments.
 */
object DataSource {

    val entreeMenuItems = listOf(
        EntreeItem(
            name = "Coliflor",
            description = "Coliflor entera, en salmuera, asada y frita.",
            price = 7.00,
        ),
        EntreeItem(
            name = "Chile de tres frijoles",
            description = "Frijoles negros, frijoles rojos, frijoles riñón, cocinados a fuego lento, cubiertos con cebolla.",
            price = 4.00,
        ),
        EntreeItem(
            name = "Pasta de champiñones",
            description = "Pasta penne, champiñones, albahaca, con tomates ciruela cocinados en ajo y aceite de oliva.",
            price = 5.50,
        ),
        EntreeItem(
            name = "Sartén de frijoles negros picantes",
            description = "Verduras de temporada, frijoles negros, mezcla de especias de la casa, servidos con aguacate y cebollas encurtidas rápidamente.",
            price = 5.50,
        )

    )

    val sideDishMenuItems = listOf(
        SideDishItem(
            name = "Ensalada de Verano",
            description = "Tomates reliquia, lechuga mantecosa, duraznos, aguacate, aderezo balsámico",
            price = 2.50,
        ),
        SideDishItem(
            name = "Sopa de Calabaza Butternut",
            description = "Calabaza butternut asada, pimientos asados, aceite de chile",
            price = 3.00,
        ),
        SideDishItem(
            name = "Papas Picantes",
            description = "Papas mármol, asadas y fritas con mezcla de especias de la casa",
            price = 2.00,
        ),
        SideDishItem(
            name = "Arroz con Coco",
            description = "Arroz, leche de coco, lima y azúcar",
            price = 1.50,
        )

    )

    val accompanimentMenuItems = listOf(
        AccompanimentItem(
            name = "Panecillo de Almuerzo",
            description = "Panecillo recién horneado hecho en casa",
            price = 0.50,
        ),
        AccompanimentItem(
            name = "Bayas Mixtas",
            description = "Fresas, arándanos, frambuesas y arándanos silvestres",
            price = 1.00,
        ),
        AccompanimentItem(
            name = "Verduras Encurtidas",
            description = "Pepinos y zanahorias encurtidos, hechos en casa",
            price = 0.50,
        )
    )
}
