/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.racetracker.ui.theme

import androidx.compose.ui.graphics.Color

val md_theme_light_primary = Color(0xFFFF5722)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFFFAB91)
val md_theme_light_onPrimaryContainer = Color(0xFFBF360C)
val md_theme_light_secondary = Color(0xFF00796B)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFF80CBC4)
val md_theme_light_onSecondaryContainer = Color(0xFF004D40)
val md_theme_light_tertiary = Color(0xFF536DFE)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFC5CAE9)
val md_theme_light_onTertiaryContainer = Color(0xFF1A237E)
val md_theme_light_error = Color(0xFFD32F2F)
val md_theme_light_errorContainer = Color(0xFFFFEBEE)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_onErrorContainer = Color(0xFFB71C1C)
val md_theme_light_background = Color(0xFFF5F5F5)
val md_theme_light_onBackground = Color(0xFF212121)
val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF212121)
val md_theme_light_surfaceVariant = Color(0xFFE0E0E0)
val md_theme_light_onSurfaceVariant = Color(0xFF616161)
val md_theme_light_outline = Color(0xFFBDBDBD)
val md_theme_light_inverseOnSurface = Color(0xFFFAFAFA)
val md_theme_light_inverseSurface = Color(0xFF303030)
val md_theme_light_inversePrimary = Color(0xFFFF8A65)
val md_theme_light_shadow = Color(0xFF000000)
val md_theme_light_surfaceTint = Color(0xFFFF5722)
val md_theme_light_outlineVariant = Color(0xFFBDBDBD)
val md_theme_light_scrim = Color(0xFF000000)

val md_theme_dark_primary = Color(0xFFFF8A65)
val md_theme_dark_onPrimary = Color(0xFFBF360C)
val md_theme_dark_primaryContainer = Color(0xFFBF360C)
val md_theme_dark_onPrimaryContainer = Color(0xFFFFAB91)
val md_theme_dark_secondary = Color(0xFF004D40)
val md_theme_dark_onSecondary = Color(0xFFFFFFFF)
val md_theme_dark_secondaryContainer = Color(0xFF80CBC4)
val md_theme_dark_onSecondaryContainer = Color(0xFF00796B)
val md_theme_dark_tertiary = Color(0xFF7986CB)
val md_theme_dark_onTertiary = Color(0xFFFFFFFF)
val md_theme_dark_tertiaryContainer = Color(0xFF3F51B5)
val md_theme_dark_onTertiaryContainer = Color(0xFFC5CAE9)
val md_theme_dark_error = Color(0xFFFF6F61)
val md_theme_dark_errorContainer = Color(0xFFB71C1C)
val md_theme_dark_onError = Color(0xFFFFFFFF)
val md_theme_dark_onErrorContainer = Color(0xFFFFEBEE)
val md_theme_dark_background = Color(0xFF212121)
val md_theme_dark_onBackground = Color(0xFFE0E0E0)
val md_theme_dark_surface = Color(0xFF212121)
val md_theme_dark_onSurface = Color(0xFFE0E0E0)
val md_theme_dark_surfaceVariant = Color(0xFF616161)
val md_theme_dark_onSurfaceVariant = Color(0xFFBDBDBD)
val md_theme_dark_outline = Color(0xFF757575)
val md_theme_dark_inverseOnSurface = Color(0xFF212121)
val md_theme_dark_inverseSurface = Color(0xFFE0E0E0)
val md_theme_dark_inversePrimary = Color(0xFFFF5722)
val md_theme_dark_shadow = Color(0xFF000000)
val md_theme_dark_surfaceTint = Color(0xFFFF8A65)
val md_theme_dark_outlineVariant = Color(0xFF616161)
val md_theme_dark_scrim = Color(0xFF000000)
